# Lab2 Maze Router
## Usage
```
make
cd bin
./0710764_lab2.o [input] [output]
```