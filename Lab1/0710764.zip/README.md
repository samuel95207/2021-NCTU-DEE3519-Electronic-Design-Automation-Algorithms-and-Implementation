# Lab1 Two-Way Partition
## Usage
```
make
cd bin
./lab1 [input]
```